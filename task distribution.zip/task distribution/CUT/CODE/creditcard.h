#include "services.h"

class CreditCard : public Service
{
    public:
        // Virtual Function
            int showData() const;
        // Member Function 
            int processCreditCardRequest() ; // Only Available For Bank Employee
            int requestForCreditCard() ;     // Only Available For Customer
};