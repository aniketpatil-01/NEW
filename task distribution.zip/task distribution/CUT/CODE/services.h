#include "allheaderfiles.h"
#pragma once

class Service
{
    public:
        // Data Table For Storing Queue Data
        static std::vector<loadStructureData>                       loanData;
        static std::vector<creditCardStructureData>                 creditCardData;
        static std::vector<coreBankingCardStructureData>            coreBankingData;
        // Update Functions
        int addLoanData();
        int addCreditCardData();
        int addBankingData();
        // Pure Virtual Function
        virtual int showData() const = 0;
        // Save Data Functions 
        int saveLoanData();
        int saveCreditCardData();
        int saveCoreBankingData();
    
};