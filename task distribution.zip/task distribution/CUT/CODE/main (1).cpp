#include "bankingInterface.h"

using namespace std;

int main()
{
    int showInterFace = 1;
    BankingService bankingObj;
    while(true)
    {
        int choice;
        if(showInterFace == 1)
        {
            std::cout<<"\t----------------------------------------------------------------------------------------"<<std::endl;
            std::cout<<"\t                  Welcome To Banking Services "<<std::endl;
            std::cout<<"\t----------------------------------------------------------------------------------------"<<std::endl;
            std::cout<<"\t Enter Following Option To Redirect You To The Employee With Required Service."<<std::endl;
            std::cout<<"\t 1. Loan Service"<<std::endl;
            std::cout<<"\t 2. Credit Card Servive"<<std::endl;
            std::cout<<"\t 3. Core Banking "<<std::endl;
            std::cout<<"\t 4. Exit "<<std::endl;
            std::cout<<"\t Enter Choice ";
            showInterFace = 2;
        }
        std::cin >> choice;
        if(choice == 4)
            break;
        if(choice == 1)
        {    
            showInterFace = bankingObj.loanInterFace();
        }
        else if(choice == 2)
        {    
            showInterFace = bankingObj.creditCardInterface();
            
        }
        else if(choice == 3)
        {    
            showInterFace = bankingObj.coreBankingInterface();
        }
        else
        {
            std::cout<<"\tInvalid Choice\nRe-Enter Choice : ";
        }
        
    }
    return 0;
}
