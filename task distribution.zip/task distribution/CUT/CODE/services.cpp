#include "services.h"
std::vector<loadStructureData>              Service :: loanData;
std::vector<creditCardStructureData>        Service :: creditCardData;
std::vector<coreBankingCardStructureData>   Service :: coreBankingData;

int Service :: addLoanData()
{
    std::string name;
    int amount;
    std::cout<<"\tEnter Name : "<<std::endl;
    std::cin>>name;
    std::cout<<"\tEnter Amount : "<<std::endl;
    std::cin>>amount;
    srand(time(0));
    int id = rand()%100000;
    loadStructureData temp = {id, name, amount, "Pending Request"};
    std::cout<<"\tYou Request Has Been Processed And It Has Been Added To Our DataBase"<<std::endl;
    std::cout<<"\t Id     : "<<id<<std::endl;
    std::cout<<"\t Name   : "<<name<<std::endl;
    std::cout<<"\t Amount : "<<amount<<std::endl;
    std::cout<<"\t Status : Pending Request"<<std::endl;
    std::cout<<"\tYour Request Will Be Processed By Our Employee Mr.Ganesh Kulkarni"<<std::endl;
    loanData.push_back(temp);
    return 1;
}

int Service :: addCreditCardData()
{
    srand(time(0));
    int id = rand()%100000;
    std::string name;
    int limit;
    int balance = 0; // Initial Balance is Zero
    std::cout<<"\tEnter Name : "<<std::endl;
    std::cin>>name;
    std::cout<<"\tEnter Limit : "<<std::endl;
    std::cin>>limit;
    creditCardStructureData temp = {id, name, limit, balance, "Pending Request"};
    std::cout<<"\tYou Request Has Been Processed And It Has Been Added To Our DataBase"<<std::endl;
    std::cout<<"\t Id     : "<<id<<std::endl;
    std::cout<<"\t Name   : "<<name<<std::endl;
    std::cout<<"\t Limit : "<<limit<<std::endl;
    std::cout<<"\t Status : Pending Request"<<std::endl;
    std::cout<<"\tYour Request Will Be Processed By Our Employee Mr.Aniket Patil"<<std::endl;
    creditCardData.push_back(temp);
    return 1;
}

int Service :: addBankingData()
{
    srand(time(0));
    int id = rand()%100000;
    std::string name;
    int deposit = 0;    // Initial deposit is Zero , 
    int withdraw = 0;   // Initial withdraw is Zero
    int balance;
    std::cout<<"\tEnter Name : "<<std::endl;
    std::cin>>name;
    std::cout<<"\tEnter Balance : "<<std::endl;
    std::cin>>balance;
    coreBankingCardStructureData temp = {id, name, balance, withdraw, deposit, "Pending Request", "Open Account"};
    std::cout<<"\tYou Request Has Been Processed And It Has Been Added To Our DataBase"<<std::endl;
    std::cout<<"\t Id     : "<<id<<std::endl;
    std::cout<<"\t Name   : "<<name<<std::endl;
    std::cout<<"\t Balance : "<<balance<<std::endl;
    std::cout<<"\t Status : Pending Request Open Account"<<std::endl;
    std::cout<<"\tYour Request Will Be Processed By Our Employee Mrs.Vaishnavi Budur"<<std::endl;
    coreBankingData.push_back(temp);
    return 1;
}

int Service :: saveLoanData()
{
    std::ofstream outfile;
    outfile.open("loanData.txt", std::ios::app);//std::ios_base::app
    for(auto& row: loanData)
    {
        outfile<<row.id<<"|"<<row.name<<"|"<<row.amount<<"|"<<row.status<<"\n";
    }
    return 1;
}
int Service :: saveCreditCardData()
{
    std::ofstream outfile;
    outfile.open("creditCardData.txt", std::ios::app);//std::ios_base::app
    for(auto& row: creditCardData)
    {
        outfile<<row.id<<"|"<<row.name<<"|"<<row.limit<<"|"<<row.balance<<row.status<<"\n";
    }
    return 1;
}
int Service :: saveCoreBankingData()
{
    std::ofstream outfile;
    outfile.open("coreBankingData.txt", std::ios::app);//std::ios_base::app
    for(auto& row: coreBankingData)
    {
        outfile<<row.id<<"|"<<row.name<<"|"<<row.balance<<"|"<<row.withdraw<<"|"<<row.deposit<<"|"<<row.status<<"|"<<row.request<<"\n";
    }
    return 1;
}

