#include "services.h"

class Loan : public Service
{
    public:
        // Virtual Function
            int showData() const;
        // Member Function 
            int processLoanRequest() ; // Only Available For Bank Employee
            int requestForLoan() ;     // Only Available For Customer
};