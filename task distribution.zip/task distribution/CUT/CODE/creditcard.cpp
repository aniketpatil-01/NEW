#include "creditcard.h"

int CreditCard :: showData()  const            // Shows The Data Of Loan
{
    for(const auto& line : creditCardData)
    {
        std::cout<<"\t| "<<line.id<<" | "<<line.name<<" | "<<line.limit<<" | "<<line.balance<<" | "<<line.status<<std::endl;
    }
    return 1;
}

int CreditCard :: processCreditCardRequest()        // Only Available To Employee
{
    showData(); // This  will show All The Data
    int id;
    std::cout<<"\tEnter Id To Process For : ";
    std::cin >> id;
    // Traversing/Going Through The Data Of Loan 
    for(auto& line : creditCardData)
    {
        if(id == line.id) // If Id Found Then Enter In The Body OF If else continue
        {    
            if(line.status == "Approved")  // If Allready Approved, Then Exit
            {
                std::cout<<"\tThe Id Request has Been Approved Already."<<std::endl;
                return 1;
            }
            else if(line.status == "Denied")  // If Allready Denied, Then Exit
            {
                std::cout<<"\tThe Id Request has Been Denied Already."<<std::endl;
                return 1;
            }
            // If Request Is Pending Then Enter In While  
            int requestApproveOrDeny;
            std::cout<<"\tEnter 1. To Approve The Request."<<std::endl;
            std::cout<<"\tEnter 2. To Deny The Request."<<std::endl;
            std::cout<<"\tEnter 3. Process Later."<<std::endl;
            while(true)
            {
                std::cin >> requestApproveOrDeny;
                if(requestApproveOrDeny == 1)
                {
                    std::string d = "Approved";
                    line.status = d;
                    std::cout<<"\tThe Request Has Been Approved."<<std::endl;
                    break;
                }
                else if(requestApproveOrDeny == 2)
                {
                    std::string d = "Denied";
                    line.status = d;
                    std::cout<<"\tThe Request Has Been Denied."<<std::endl;
                    break;
                }
                else if(requestApproveOrDeny == 3)
                {
                    std::cout<<"\tNo Operation Done On Request [ Pending... ]."<<std::endl;
                    break;
                }
                else
                {
                    std::cout<<"\tInvalid Input."<<std::endl;
                    continue;
                }
                
            }
            return 1;
        }
    }
    return 1;
}

int CreditCard :: requestForCreditCard()            // Only Available For Customer
{
    addCreditCardData();  // Already Present In Abstract Class 
    return 1;
}
