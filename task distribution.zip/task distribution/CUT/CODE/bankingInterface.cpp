#include "bankingInterface.h"

int BankingService :: loanInterFace() {
    int showInterface = 1;
    while(true)
    {
        if(showInterface == 1)
        {
            std::cout<<"\t1. Apply For Loan"<<std::endl;
            std::cout<<"\t2. Show Loan Data"<<std::endl;
            std::cout<<"\t3. Process Loan Requests"<<std::endl;
            std::cout<<"\t4. Go Back : ";
            showInterface = 2;
        }
        int choice;
        std::cin>>choice;
        if(choice == 1) {
            showInterface = loanEmployeeObject.applyForLoan();
        }
        else if(choice == 2) {
            showInterface = loanEmployeeObject.showDataOfLoan();
        }
        else if(choice == 3) {
            showInterface = loanEmployeeObject.processRequestsForLoan();
        }
        else if(choice == 4)
        {
            return 1;
        }
        else
        {
            std::cout<<"\tInvalid Input\n\tRe-Enter Choice : ";
        }
    }
}

int BankingService :: creditCardInterface() {
    int showInterface = 1;
    while(true)
    {
        if(showInterface == 1)
        {
            std::cout<<"\t1. Apply For Credit Card"<<std::endl;
            std::cout<<"\t2. Show Credit Card Data"<<std::endl;
            std::cout<<"\t3. Process Credit Card Requests"<<std::endl;
            std::cout<<"\t4. Go Back : ";
            showInterface = 2;
        }
        int choice;
        std::cin>>choice;
        if(choice == 1)      {
            showInterface = creditCardEmployeeObject.applyForCreditCard();
        }
        else if(choice == 2) {
            showInterface = creditCardEmployeeObject.showDataOfCreditCard();
        }
        else if(choice == 3) {
            showInterface = creditCardEmployeeObject.processRequestsForCreditCard();
        }
        else if(choice == 4)
        {
            return 1;
        }
        else
        {
            std::cout<<"\tInvalid Input\n\tRe-Enter Choice : ";
        }
    }
    
}

int BankingService :: coreBankingInterface() {
    int showInterface = 1;
    while(true)
    {
        if(showInterface == 1)
        {
            std::cout<<"\t1. Apply For Opening Account"<<std::endl;
            std::cout<<"\t2. Show Transaction Data"<<std::endl;
            std::cout<<"\t3. Process Transaction Requests"<<std::endl;
            std::cout<<"\t4. Request For Withdraw"<<std::endl;
            std::cout<<"\t5. Request For Deposit"<<std::endl;
            std::cout<<"\t6. Go Back : "<<std::endl;
            showInterface = 2;
        }
        int choice;
        std::cin>>choice;
        
        if(choice == 1) {
            showInterface = coreBankingEmployeeObject.applyForOpenAccount();
        }
        else if(choice == 2) {
            showInterface = coreBankingEmployeeObject.showDataOfTransaction();
        }
        else if(choice == 3) {
            showInterface = coreBankingEmployeeObject.processRequestsForTransaction();
        }
        else if(choice == 4){
            showInterface = coreBankingEmployeeObject.requestWithdraw();
        }
        else if(choice == 5){
            showInterface = coreBankingEmployeeObject.requestDeposit();
        }
        else if(choice == 6)
        {
            return 1;
        }
        else {
            std::cout<<"\tInvalid Input\n\tRe-Enter Choice : ";
        }
    }
}
    
