#pragma once
#include "loan.h"
#include "creditcard.h"
#include "corebanking.h"

class LoanEmployee {
    private:
        int employeeId;
        Loan loanObject;
        std::string employeeName;
    public :
        LoanEmployee();
    // Loan Requests 
        int applyForLoan() ;                    // For Customer
        int processRequestsForLoan();           // For Employee
        int showDataOfLoan() ;                  // For Employee
};

class CreditCardEmployee {
    private:
        int employeeId;
        std::string employeeName;
        CreditCard creditCardObject;
    public :
        CreditCardEmployee();
    // Credit Card 
        int applyForCreditCard() ;                    // For Customer
        int processRequestsForCreditCard();           // For Employee
        int showDataOfCreditCard() ;                  // For Employee
};

class CoreBankingEmployee {
    int employeeId;
    std::string employeeName;
    CoreBanking coreBankingObject;
    public :
        CoreBankingEmployee();
    // Core Banking
        int applyForOpenAccount() ;                    // For Customer
        int processRequestsForTransaction();           // For Employee
        int showDataOfTransaction() ;                  // For Employee
        int requestWithdraw();                  
        int requestDeposit();
};

// ------------------------------------------------------------------------
class BankingService
{
    private:
        LoanEmployee loanEmployeeObject;
        CreditCardEmployee creditCardEmployeeObject;
        CoreBankingEmployee coreBankingEmployeeObject;
    public:
    // Banking Services
        int loanInterFace();
        int creditCardInterface();
        int coreBankingInterface();
};
