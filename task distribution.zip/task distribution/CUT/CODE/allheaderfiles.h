#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <thread>
#include <iomanip>
#include <cstdlib>
#include <fstream>

struct loadStructureData
{
    int id;
    std::string name;
    int amount;
    std::string status;
};

struct creditCardStructureData
{
    int id;
    std::string name;
    int limit;
    int balance;
    std::string status;
};

struct coreBankingCardStructureData
{
    int id;
    std::string name;
    int balance;
    int withdraw;
    int deposit;
    std::string status; // Approve, Deny ,pendingWithdraw, pendingDeposit, Pending
    std::string request;
};