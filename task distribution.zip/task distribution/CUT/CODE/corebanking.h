#include "services.h"

class CoreBanking : public Service
{
    public:
        // Virtual Function
            int showData() const;
        // Member Function 
            int processCoreBankingRequest() ; // Only Available For Bank Employee
            int requestForCoreBanking() ;     // Only Available For Customer
            int requestForDeposit();
            int requestForWithdraw();
};